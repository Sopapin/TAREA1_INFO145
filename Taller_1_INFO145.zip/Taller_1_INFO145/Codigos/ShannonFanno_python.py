# se importan las librerias a utilizar
from collections import Counter
from sys import argv
import operator
import random
import os
import time
import psutil


# Programa principal


def main():
    titulo = validaTexto()
    nombre = leerTexto(titulo)
    # se definen variables
    dicc = Counter(nombre)
    largo = len(nombre)
    simb = (len(dicc.keys()))
    percent = []
    binario = []
    # se ordena el diccionario con sus letras y frecuencia
    dicc = dict(sorted(dicc.items(), key=operator.itemgetter(1), reverse=True))
    for i in range(simb):
        binario.append('')
    # a percent se le agrega los porcentajes
    for i in dicc.keys():
        dicc[i] = dicc[i]/largo
        percent.append(dicc[i])
    inicio = 0
    p = 0
    final = simb-1
    # retona binario con la codicacion de cada letra y ordenadas descendentemente
    binario = divisionSub(binario, percent, inicio, final, p)
    keys = list(dicc.keys())
   # for j in range(simb):
    #    print(keys[j], "=", binario[j])
    # retorna todo el texto  codificado
    cond = transformaTexto(binario, dicc, nombre)

    #Funcion creada para los experimentos
    dicc_binario = obtener_dicc_binario(binario)

    # Experimentos

    print("Experimento 1")
    # Calculos de tiempo de ejeución
    in_exp1 = time.process_time()
    experimento1(cond, largo, binario, keys, dicc_binario)
    fin_exp1 = time.process_time()
    print("Se demoro : {} ".format(fin_exp1-in_exp1))
    # Funcion que calcula la memoria RAM utilizada
    memoria = memory_usage()
    print("RAM: ", memoria, "MB")
    print("Experimento 2")
    in_exp2 = time.process_time()
    experimento2(cond, largo, binario, keys, dicc_binario)
    fin_exp2 = time.process_time()
    print("Se demoro : {} ".format(in_exp2-in_exp2))
    # Funcion que calcula la memoria RAM utilizada
    memoria = memory_usage()
    print("RAM: ", memoria, "MB")


def obtener_dicc_binario(binario):
    dicc_binario = {}
    for i in range(len(binario)):
        l = len(binario[i])
        if (dicc_binario.get(l) == None):
            arr = []
            arr.append(binario[i])
            dicc_binario.setdefault(l, arr)
        else:
            dicc_binario[l].append(binario[i])
    return dicc_binario

# Funcion que realiza el experimento 1 del trabajo
def experimento1(cond, largo, binario, keys, dicc_binario):
    k = random.randint(1, largo)
    z = ''
    frase = ''
    m = 0
    #Se comparan los elementos y se escribe hasta la k letra
    #Explicado en profundidad en el informe.
    for j in range(k):
        C = True
        while(C):
            if (dicc_binario.get(len(z)) != None):
                for i in (dicc_binario[len(z)]):
                    if(z == i):
                        frase = frase+keys[binario.index(i)]
                        C = False
                        z = ''
            if(C == True):
                z = z + cond[m]
                m = m + 1
    return frase


# Funcion que realiza el experimento 2 del trabajo
def experimento2(cond, largo, binario, keys, dicc_binario):
    i=random.randint(1,largo)
    j=random.randint(1,largo)
    while(j<i):
        j=random.randint(1,largo)
    z = ''
    frase = ''
    m = 0
    cont2 = 0
    #Empieza desde el comienzo buscando la i, luego realiza
    #lo mismo que en el experimento 1 hasta j, explicado en profundidad en el informe
    while(cont2 < j):
        C = True
        while(C):
            if (dicc_binario.get(len(z)) != None):
                for k in (dicc_binario[len(z)]):
                    if(z == k):
                        z = '' 
                        cont2 = cont2 + 1
                        if(cont2 >= i) and (cont2 < j+1):
                            frase = frase+keys[binario.index(k)]
                            C = False
            if(C == True):
                z = z + cond[m]
                m = m+1
    return frase


def memory_usage():  # Funcion que calcula el espacio requerido en RAM
    # retorna la memoria usada en MB
    process = psutil.Process(os.getpid())
    mem = process.memory_info().rss / float(2 ** 20)
    return mem


def divisionSub(binario, percent, inicio, final, p):
    # se calcula la mitad de los porcentajes
    mitad = sum(percent[inicio:final])/2
    # se agregan 1 y 0 dependiendo de la condicion recursivamente
    if (final-1 == inicio):
        binario[inicio] += '1'
        binario[final] += '0'
    elif (inicio < final):
        p, inicio, final = pivote(inicio, final, percent, p, mitad)
        for i in range(inicio, p+1):
            binario[i] += '1'
        for j in range(p+1, final+1):
            binario[j] += '0'
        divisionSub(binario, percent, inicio, p, p)
        divisionSub(binario, percent, p+1, final, p)
    return(binario)


def pivote(inicio, final, percent, p, mitad):
    # se deja el pivote para buscar el mas cercano a la mitad
    cont = percent[inicio]
    i = inicio
    mitad = sum(percent[inicio:final])/2
    while (cont+percent[i+1] <= mitad):
        i += 1
        cont += percent[i]
    p = i
    if (abs(cont-mitad) < abs(cont+percent[i+1]-mitad)):  # valor absoluto
        return p, inicio, final
    else:
        return p+1, inicio, final


def validaTexto():
    # valida el texto ingresado cumpla con las condiciones
    class error(Exception):
        pass

    class nada(error):
        pass

    class espacio(error):
        pass
    sigue = True
    while (sigue):
        try:
            nombre = input('Ingrese el nombre del archivo: ')
            if(len(nombre) == 0):
                raise nada
            elif(len(nombre.replace(' ', '')) == 0):
                raise espacio
            else:
                archivo = open(nombre, 'r')
                archivo.close()
                return(nombre)
                sigue = False
        except(FileNotFoundError):
            print('Archivo no existe!')
        except(nada):
            print('Nada ingreso')
        except (espacio):
            print('Ingreso solo espacios')


def leerTexto(nombre):  # lee el texto
    with open(nombre, 'r', encoding="utf8", errors='ignore') as x:
        m = (x.read())
        return (m)

# cambia todas las letras del texto con su codicacion correspondiente
def transformaTexto(b, k, simb):
    codificacion = ''
    for i in range(len(simb)):
        codificacion += b[list(k.keys()).index(simb[i])]
    return (codificacion)


main()
