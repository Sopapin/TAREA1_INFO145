# se importan las librerias a utilizar
from collections import Counter
from sys import argv
import operator
import random
import os
import time
import psutil


# Programa principal


def main():
    script, texto, opcion = argv
    kS = [19931714, 44653750, 28787128, 15727745, 20735259, 20354999, 24836302, 26723324, 34274817, 17868259,
          11794114, 8081692, 30103297, 52213884, 24224268, 36601229, 19407333, 36945837, 7776873, 3762734]
    iS = [40252147, 10005395, 22432489, 16014842, 35019582, 17514636, 32419000, 45099815, 34337423, 41642756,
          15383788, 48468586, 11275877, 38247478, 2895645, 3748311, 22149968, 13338250, 45678732, 45655096]
    jS = [47889086, 14001147, 41334298, 37452609, 41851285, 46010831, 47647183, 47190522, 40844807, 42920933,
          22695831, 49452629, 19141867, 48087054, 28506426, 23531196, 23691543, 26388194, 51896498, 52339334]
    titulo = validaTexto(texto)
    nombre = leerTexto(titulo)
    # se definen variables
    dicc = Counter(nombre)
    largo = len(nombre)
    simb = (len(dicc.keys()))
    percent = []
    binario = []
    # se ordena el diccionario con sus letras y frecuencia
    dicc = dict(sorted(dicc.items(), key=operator.itemgetter(1), reverse=True))
    for i in range(simb):
        binario.append('')
    # a percent se le agrega los porcentajes
    for i in dicc.keys():
        dicc[i] = dicc[i]/largo
        percent.append(dicc[i])
    inicio = 0
    p = 0
    final = simb-1
    # retona binario con la codicacion de cada letra y ordenadas descendentemente
    binario = divisionSub(binario, percent, inicio, final, p)
    keys = list(dicc.keys())
    # for j in range(simb):
    #    print(keys[j], "=", binario[j])
    # retorna todo el texto  codificado
    cond = transformaTexto(binario, dicc, nombre)
    # Experimentos
    # Calculos de tiempo de ejeucion
    dicc_binario = obtener_dicc_binario(binario)
    if (opcion == '0'):
        print("Experimento 1")
        for i in range(20):
            in_exp1 = time.process_time()
            experimento1(cond, largo, binario, keys, kS[i], dicc_binario)
            fin_exp1 = time.process_time()
            print("REP: {} Se demoro : {} ".format(i, (fin_exp1-in_exp1)))
            memoria = memory_usage()
            print("RAM: ", memoria, "MB")
    else:
        print("Experimento 2")
        for i in range(20):
            in_exp2 = time.process_time()
            experimento2(cond, largo, binario, keys,
                         iS[i], jS[i], dicc_binario)
            fin_exp2 = time.process_time()
            print("REP: {} Se demoro : {} ".format(i, (fin_exp2-in_exp2)))
            memoria = memory_usage()
            print("RAM: ", memoria, "MB")
    # Funcion que calcula la memoria RAM utilizada


def obtener_dicc_binario(binario):
    dicc_binario = {}
    for i in range(len(binario)):
        l = len(binario[i])
        if (dicc_binario.get(l) == None):
            arr = []
            arr.append(binario[i])
            dicc_binario.setdefault(l, arr)
        else:
            dicc_binario[l].append(binario[i])
    return dicc_binario

# Funcion que realiza el experimento 1 del trabajo


def experimento1(cond, largo, binario, keys, k, dicc_binario):
    # print("k: ",k)

    z = ''
    frase = ''
    m = 0
    # Se compara el string z con el arreglo bin hasta que sean iguales
    # cuando son iguales se agrega a frase y el z vuelve a vaciarse
    for j in range(k):
        C = True
        while(C):
            if (dicc_binario.get(len(z)) != None):
                for i in (dicc_binario[len(z)]):
                    if(z == i):
                        frase = frase+keys[binario.index(i)]
                        C = False
                        z = ''
            if(C == True):
                z = z + cond[m]
                m = m + 1
    return frase


# Funcion que realiza el experimento 2 del trabajo
def experimento2(cond, largo, binario, keys, i, j, dicc_binario):
    i=random.randint(1,largo)
    j=random.randint(1,largo)
    while(j<i):
        j=random.randint(1,largo)
    z = ''
    frase = ''
    m = 0
    cont2 = 0
    #Empieza desde el comienzo buscando la i, luego realiza
    #lo mismo que en el experimento 1 hasta j, explicado en profundidad en el informe
    while(cont2 < j):
        C = True
        while(C):
            if (dicc_binario.get(len(z)) != None):
                for k in (dicc_binario[len(z)]):
                    if(z == k):
                        z = '' 
                        cont2 = cont2 + 1
                        if(cont2 >= i) and (cont2 < j+1):
                            frase = frase+keys[binario.index(k)]
                            C = False
            if(C == True):
                z = z + cond[m]
                m = m+1
    return frase


def memory_usage():  # Funcion que calcula el espacio requerido en RAM
    # retorna la memoria usada en MB
    process = psutil.Process(os.getpid())
    mem = process.memory_info().rss / float(2 ** 20)
    return mem


def divisionSub(binario, percent, inicio, final, p):
    # se calcula la mitad de los porcentajes
    mitad = sum(percent[inicio:final])/2
    # se agregan 1 y 0 dependiendo de la condicion recursivamente
    if (final-1 == inicio):
        binario[inicio] += '1'
        binario[final] += '0'
    elif (inicio < final):
        p, inicio, final = pivote(inicio, final, percent, p, mitad)
        for i in range(inicio, p+1):
            binario[i] += '1'
        for j in range(p+1, final+1):
            binario[j] += '0'
        divisionSub(binario, percent, inicio, p, p)
        divisionSub(binario, percent, p+1, final, p)
    return(binario)


def pivote(inicio, final, percent, p, mitad):
    # se deja el pivote para buscar el mas cercano a la mitad
    cont = percent[inicio]
    i = inicio
    mitad = sum(percent[inicio:final])/2
    while (cont+percent[i+1] <= mitad):
        i += 1
        cont += percent[i]
    p = i
    if (abs(cont-mitad) < abs(cont+percent[i+1]-mitad)):  # valor absoluto
        return p, inicio, final
    else:
        return p+1, inicio, final


def validaTexto(nombre_archivo):
    # valida el texto ingresado cumpla con las condiciones
    class error(Exception):
        pass

    class nada(error):
        pass

    class espacio(error):
        pass
    sigue = True
    while (sigue):
        try:
            nombre = nombre_archivo
            if(len(nombre) == 0):
                raise nada
            elif(len(nombre.replace(' ', '')) == 0):
                raise espacio
            else:
                archivo = open(nombre, 'r')
                archivo.close()
                return(nombre)
                sigue = False
        except(FileNotFoundError):
            print('Archivo no existe!')
        except(nada):
            print('Nada ingreso')
        except (espacio):
            print('Ingreso solo espacios')


def leerTexto(nombre):  # lee el texto
    with open(nombre, 'r', encoding="utf8", errors='ignore') as x:
        m = (x.read())
        return (m)

# cambia todas las letras del texto con su codicacion correspondiente
def transformaTexto(b, k, simb):
    codificacion = ''
    for i in range(len(simb)):
        codificacion += b[list(k.keys()).index(simb[i])]
    return (codificacion)


main()
