// readme.txt
En esta carpeta están los códigos de experimentación. 
Estos tienen los mismos arreglos para cada experimentación y para cada archivo de texto.
Cabde destacar que SOLO fueron utilizados y adaptados para poder hacer el análisis más facilmente,
los códigos originales se encuentran en la carpeta "Códigos".
