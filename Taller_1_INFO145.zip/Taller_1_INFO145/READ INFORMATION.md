# Taller_1_INFO145
Dentro de la carpeta principal se encuentran dos carpetas adicionales mas el informe del trabajo realizado.

En la carpeta "Codigos" se encuentran los codigos "originales" realizados por el equipo tanto como de Shannon Fano como 
Huffman Canonico como Shannon Fanno .Ademas, de un pequeño analisis extra 
del comportamiento de la memoria RAM de huffman.

En la carpeta "Codigos_experimentacion" se encuentras 4 archivos que corresponen a la experimentacion realizada ya que 
tienen una diferencia de los codigos originales. Estos tienen los mismos arreglos para cada uno y para 
cada archivo de texto (sirve para dna y english 50MB). 
A arreglos nos referimos a los mismos "i", "j" y "k". Adjuntando su respectivo makefile.

